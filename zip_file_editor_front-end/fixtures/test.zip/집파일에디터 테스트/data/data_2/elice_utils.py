# test
money = 5

# test
money = 6

# test
print( money )